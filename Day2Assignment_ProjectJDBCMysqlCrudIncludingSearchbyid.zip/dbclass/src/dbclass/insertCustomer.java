package dbclass;
import java.sql.*;
import java.util.Scanner;

public class insertCustomer {
	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static final String query = "insert into customer(id,name,age,address,salary) values (?,?,?,?,?)";

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(query);
				){
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter new Customer id");
			int id = sc.nextInt();
			System.out.println("Enter new Customer name");
			String name = sc.next();
			System.out.println("Enter new Customer age");
			int age = sc.nextInt();
			System.out.println("Enter new Address");
			String address = sc.next();
			System.out.println("Enter new Salary");
			String salary = sc.next();
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, age);
			ps.setString(4, address);
			ps.setString(5, salary);
			
			ps.executeUpdate();
			
		}catch(SQLException e) {
			System.out.println(e);
		}
	}

}
