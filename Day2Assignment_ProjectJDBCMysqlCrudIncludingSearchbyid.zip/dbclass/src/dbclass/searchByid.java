package dbclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.cj.xdevapi.PreparableStatement;

public class searchByid {

	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static String query= "Select * from customer where id = ";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer id to be searched:");
		String id = sc.next();
		query += id;
		try(Connection con = DriverManager.getConnection(dburl,user,pass);
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(query);
						)
		{
			
			
			System.out.println("ID Name Age Address Salary");
			while(rs.next()) {
				System.out.print(" "+rs.getInt("id"));
				System.out.print(" "+rs.getString("name"));
				System.out.print(" "+rs.getInt("age"));
				System.out.print(" "+rs.getString("address"));
				System.out.print(" "+rs.getString("salary"));
				
			}
		
	}catch(Exception e) {
	System.out.println(e);	
	}
	}

}
