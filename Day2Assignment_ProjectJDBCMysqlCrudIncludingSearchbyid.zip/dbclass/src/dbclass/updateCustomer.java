package dbclass;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class updateCustomer {

	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	static final String query = "update customer set salary = ? where id = ?";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(query)){
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Customer id whose salary needs to be increase");
			int id = sc.nextInt();
			System.out.println("Enter Customer salary to be updated");
			String salary = sc.next();
			ps.setString(1, salary);
			ps.setInt(2, id);
			ps.executeUpdate();
		
	}
		catch(SQLException e) {
			System.out.println(e);
		}
	}
}
