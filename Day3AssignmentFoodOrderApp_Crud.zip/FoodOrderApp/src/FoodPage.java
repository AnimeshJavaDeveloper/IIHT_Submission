import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class FoodPage {
	static final String dburl = "jdbc:mysql://localhost:3306/student";
	static final String user = "root";
	static final String pass= "pass@word1";
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("####FOOD ORDER APP####");
		System.out.println("Press 1 to Signup");
		System.out.println("Press 2 to Signin");
		System.out.println("Press e to exit");
		
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		
		switch(input) {
		case 1: signup();
		break;
		case 2: signin();
		break;
		case 3: System.out.println("Thanks for visiting");
		break;
		}
	}
	
	private static void signup() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter new username(emailid)");
		String name = sc.next();
		System.out.println("Enter new password");
		String password = sc.next();
		
		if(registerDb(name,password)>0) {
			System.out.println("user register successfully");
			
		}
		else {
			System.out.println("Error occured while registring");
		}

	}

	private static int registerDb(String emailid, String password) {
		// TODO Auto-generated method stub
		String sql = "insert into foodreg(emailid,password) values (?,?)";
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(sql)){
			ps.setString(1, emailid);
			ps.setString(2, password);
			return ps.executeUpdate();
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		return 0;
	}

	private static void signin() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter registered userid");
		String emailid = sc.next();
		System.out.println("Enter pass");
		String pass = sc.next();
		
		if(login(emailid,pass)!=null) {
			System.out.println("HI "+emailid);
			System.out.println("Press 1 to Order/Add food");
			System.out.println("Press 2 to Delete food from order");
			System.out.println("Press 3 to Count total");
			System.out.println("Press 4 to Logout");
			int option = sc.nextInt();
			switch(option) {
			
			case 1:System.out.println("1 for Pizza -Rs. 40");
				   System.out.println("2 for Sandwitch -Rs. 80");
				   System.out.println("3 for Soup -Rs. 30");
				   System.out.println("4 for Rolls -Rs. 100");
				   int fo = sc.nextInt();
				   order(emailid,fo);
				   break;
			case 2:System.out.println("1 for remove Pizza -Rs. 40");
			   System.out.println("2 for remove Sandwitch -Rs. 80");
			   System.out.println("3 for remove Soup -Rs. 30");
			   System.out.println("4 for remove Rolls -Rs. 100");
			   int ro = sc.nextInt();
			  rem(emailid,ro);
			   	break;
			case 3:
				countMoney(emailid);
				break;
			case 4:
				break;
			
			}
			
		}
		else {
			System.out.println("Invalid credential");
		}
	}

	private static void countMoney(String emailid) {
		// TODO Auto-generated method stub
		String sql = "select sum(price) as a from foodcart where emailid =?";
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(sql)){
			ps.setString(1,emailid);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
			System.out.println(rs.getInt("a"));
			}
		}catch(SQLException e) {
			System.out.println(e);
		}
		
		
	}

	private static void rem(String emailid, int ro) {
		// TODO Auto-generated method stub
		String sql = "delete from foodcart where emailid = ? and item = ?)";
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(sql)){
			ps.setString(1, emailid);
			if(ro == 1) {
				ps.setString(2, "pizza");
				
			}else if(ro == 2){
				ps.setString(2, "Sandwitch");
			}else if(ro == 3){
				ps.setString(2, "Soup");
			}else {
				ps.setString(2, "Rolls");
			}				
			
			if(ps.executeUpdate()>0) {
				System.out.println("removed successfully");
			}
			else {
				System.out.println("removal failed");
			}
			
			
						
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		
	}

	private static void order(String emailid,int fo) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				String sql = "insert into foodcart(emailid,item, price) values (?,?,?)";
				try(Connection conn = DriverManager.getConnection(dburl, user, pass);
						PreparedStatement ps = conn.prepareStatement(sql)){
					
					ps.setString(1, emailid);
					if(fo == 1) {
						ps.setString(2, "pizza");
						ps.setInt(3, 40);
					}else if(fo == 2){
						ps.setString(2, "Sandwitch");
						ps.setInt(3, 80);
					}else if(fo == 3){
						ps.setString(2, "Soup");
						ps.setInt(3, 30);
					}else {
						ps.setString(2, "Rolls");
						ps.setInt(3, 100);
					}				
					
					if(ps.executeUpdate()>0) {
						System.out.println("Order successfully");
					}
					else {
						System.out.println("order failed");
					}
					
				}catch(SQLException e) {
					System.out.println(e);
				}
		
	}

	private static Object login(String emailid, String pass2) {
		// TODO Auto-generated method stub
		String sql = "select * from foodreg where emailid = ? and password = ?";
		try(Connection conn = DriverManager.getConnection(dburl, user, pass);
				PreparedStatement ps = conn.prepareStatement(sql)){
			ps.setString(1, emailid);
			ps.setString(2, pass2);
			return ps.executeQuery();
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		
		return null;
	}

	

}
